# NAME - ABHINANDAN MONDAL
# ROLL NO. - 23CS60R34
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt

transform_norm = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.1307,), (0.3081,))
])

transform = transforms.Compose([
    transforms.ToTensor()
])

train_dataset_norm = datasets.MNIST(root='./data', train=True, download=True, transform=transform_norm)
test_dataset_norm = datasets.MNIST(root='./data', train=False, download=True, transform=transform_norm)

train_dataset = datasets.MNIST(root='./data', train=True, download=True, transform=transform)
test_dataset = datasets.MNIST(root='./data', train=False, download=True, transform=transform)

train_loader_norm = DataLoader(dataset=train_dataset_norm, batch_size=256, shuffle=True)
test_loader_norm = DataLoader(dataset=test_dataset_norm, batch_size=256, shuffle=False)

train_loader = DataLoader(dataset=train_dataset, batch_size=256, shuffle=True)
test_loader = DataLoader(dataset=test_dataset, batch_size=256, shuffle=False)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Experiment 1
class CNNVanilla(nn.Module):
    def __init__(self):
        super(CNNVanilla, self).__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, stride=1, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1)
        self.fc1 = nn.Linear(7*7*64, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x):
        x = torch.relu(self.conv1(x))
        x = torch.max_pool2d(x, 2)
        x = torch.relu(self.conv2(x))
        x = torch.max_pool2d(x, 2)
        x = x.view(-1, 7*7*64)
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x

class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(ResidualBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1)
        self.relu = nn.ReLU()
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.bn2 = nn.BatchNorm2d(out_channels)
        if in_channels != out_channels:
            self.downsample = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, padding=0),
                nn.BatchNorm2d(out_channels)
            )
        else:
            self.downsample = None

    def forward(self, x):
        identity = x
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        out = self.conv2(out)
        out = self.bn2(out)
        if self.downsample is not None:
            identity = self.downsample(x)
        out += identity
        out = self.relu(out)
        return out

class CNNResnet(nn.Module):
    def __init__(self):
        super(CNNResnet, self).__init__()
        self.layer1 = ResidualBlock(1, 32)
        self.layer2 = ResidualBlock(32, 64)
        self.fc1 = nn.Linear(7*7*64, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x):
        x = self.layer1(x)
        x = torch.max_pool2d(x, 2)
        x = self.layer2(x)
        x = torch.max_pool2d(x, 2)
        x = x.view(-1, 7*7*64)
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x
    
criterion = nn.CrossEntropyLoss()
def train_and_evaluate(model, optimizer, train_loader, test_loader, epochs=50):
    model.to(device)
    train_accuracies = []
    
    for epoch in range(epochs):
        model.train()
        correct = 0
        total = 0
        for batch_idx, (data, target) in enumerate(train_loader):
            data, target = data.to(device), target.to(device)
            
            optimizer.zero_grad()
            output = model(data)
            loss = criterion(output, target)
            loss.backward()
            optimizer.step()
            
            pred = output.argmax(dim=1, keepdim=True)
            correct += pred.eq(target.view_as(pred)).sum().item()
            total += target.size(0)
        
        train_accuracy = 100. * correct / total
        train_accuracies.append(train_accuracy)
        print(f'Epoch {epoch+1}/{epochs}, Training Accuracy: {train_accuracy:.2f}%')
    
    model.eval()
    test_loss = 0
    correct = 0
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            test_loss += criterion(output, target).item()
            pred = output.argmax(dim=1, keepdim=True)
            correct += pred.eq(target.view_as(pred)).sum().item()

    test_loss /= len(test_loader.dataset)
    test_accuracy = 100. * correct / len(test_loader.dataset)
    print('\nTest set: Average loss: {:.4f}, Accuracy: {}/{} ({:.0f}%)\n'.format(
        test_loss, correct, len(test_loader.dataset), test_accuracy))
    
    return train_accuracies, test_accuracy

model_vanilla = CNNVanilla().to(device)
optimizer_vanilla = optim.Adam(model_vanilla.parameters(), lr=0.001)

train_accuracies_vanilla, test_accuracy_vanilla = train_and_evaluate(model_vanilla, optimizer_vanilla, train_loader, test_loader)

model_resnet = CNNResnet().to(device)
optimizer_resnet = optim.Adam(model_resnet.parameters(), lr=0.001)

train_accuracies_resnet, test_accuracy_resnet = train_and_evaluate(model_resnet, optimizer_resnet, train_loader, test_loader)

print(f'CNN-Vanilla Accuracy: {test_accuracy_vanilla}%')
print(f'CNN-Resnet Accuracy: {test_accuracy_resnet}%')

epochs = range(1, 51)

plt.figure(figsize=(10, 6))
plt.plot(epochs, train_accuracies_vanilla, 'b-', label='CNN-Vanilla Training Accuracy')
plt.plot(epochs, train_accuracies_resnet, 'r-', label='CNN-Resnet Training Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy (%)')
plt.title('Training Accuracy vs. Epochs')
plt.legend()
plt.show()

# Experiment 2
model_resnet_norm = CNNResnet().to(device)
optimizer_resnet_norm = optim.Adam(model_resnet_norm.parameters(), lr=0.001)

print("Training and evaluating CNN-Resnet with normalized data...")
train_accuracies_resnet_norm, test_accuracy_resnet_norm = train_and_evaluate(model_resnet_norm, optimizer_resnet_norm, train_loader_norm, test_loader_norm)

model_resnet_no_norm = CNNResnet().to(device)
optimizer_resnet_no_norm = optim.Adam(model_resnet_no_norm.parameters(), lr=0.001)

print("Training and evaluating CNN-Resnet without normalized data...")
train_accuracies_resnet_no_norm, test_accuracy_resnet_no_norm = train_and_evaluate(model_resnet_no_norm, optimizer_resnet_no_norm, train_loader, test_loader)

print(f'CNN-Resnet Accuracy with normalization: {test_accuracy_resnet_norm}%')
print(f'CNN-Resnet Accuracy without normalization: {test_accuracy_resnet_no_norm}%')

epochs = range(1, 51)

plt.figure(figsize=(10, 7))
plt.plot(epochs, train_accuracies_resnet_norm, 'b-', label='With Normalization', marker='o')
plt.plot(epochs, train_accuracies_resnet_no_norm, 'r-', label='Without Normalization', marker='x')
plt.title('Training Accuracy vs. Epochs for CNN-Resnet')
plt.xlabel('Epochs')
plt.ylabel('Training Accuracy (%)')
plt.legend()
plt.grid(True)
plt.show()

# Experiment 3
optimizers_config = [
    ('SGD', optim.SGD, {'lr': 0.001}),
    ('SGD_no_momentum', optim.SGD, {'lr': 0.001, 'momentum': 0}),
    ('SGD_momentum', optim.SGD, {'lr': 0.001, 'momentum': 0.9}),
    ('ADAM', optim.Adam, {'lr': 0.001})
]

detailed_results = {}

for opt_name, optimizer_class, opt_params in optimizers_config:
    print(f"\nTraining with {opt_name} optimizer...")
    model_resnet = CNNResnet().to(device)
    optimizer = optimizer_class(model_resnet.parameters(), **opt_params)
    
    train_accuracies, test_accuracy = train_and_evaluate(model_resnet, optimizer, train_loader_norm, test_loader_norm)
    detailed_results[opt_name] = (train_accuracies, test_accuracy)
    print(f"{opt_name} Test Accuracy: {test_accuracy:.2f}%")

print("\nFinal Results:")
for opt_name, accuracy in detailed_results.items():
    print(f"{opt_name} Accuracy: {test_accuracy}%")

epochs = range(1, 51)

plt.figure(figsize=(12, 8))
for opt_name, (train_accuracies, _) in detailed_results.items():
    plt.plot(epochs, train_accuracies, label=f'{opt_name}')

plt.xlabel('Epoch')
plt.ylabel('Training Accuracy (%)')
plt.title('Training Accuracy vs. Epochs for Different Optimizers')
plt.legend()
plt.grid(True)
plt.show()

# Experiment 4
class CNNResnetDeepConv(nn.Module):
    def __init__(self):
        super(CNNResnetDeepConv, self).__init__()
        self.layer1 = ResidualBlock(1, 32)
        self.layer2 = ResidualBlock(32, 64)
        self.layer3 = ResidualBlock(64, 128)
        self.layer4 = ResidualBlock(128, 256)
        self.fc1 = nn.Linear(256, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x):
        x = self.layer1(x)
        x = torch.max_pool2d(x, 2)
        x = self.layer2(x)
        x = torch.max_pool2d(x, 2)
        x = self.layer3(x)
        x = torch.max_pool2d(x, 2)
        x = self.layer4(x)
        x = torch.max_pool2d(x, 2)
        x = x.view(-1, 256)
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x
    
class CNNResnetDeepFC(nn.Module):
    def __init__(self):
        super(CNNResnetDeepFC, self).__init__()
        self.layer1 = ResidualBlock(1, 32)
        self.layer2 = ResidualBlock(32, 64)
        self.layer3 = ResidualBlock(64, 128)
        self.fc1 = nn.Linear(128 * 3 * 3, 256)
        self.fc2 = nn.Linear(256, 256)
        self.fc3 = nn.Linear(256, 128)
        self.fc4 = nn.Linear(128, 10)

    def forward(self, x):
        x = self.layer1(x)
        x = torch.max_pool2d(x, 2)
        x = self.layer2(x)
        x = torch.max_pool2d(x, 2)
        x = self.layer3(x)
        x = torch.max_pool2d(x, 2)
        x = x.view(-1, 128 * 3 * 3)
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = torch.relu(self.fc3(x))
        x = self.fc4(x)
        return x
    
model_deep_conv = CNNResnetDeepConv().to(device)
model_deep_fc = CNNResnetDeepFC().to(device)

optimizer_deep_conv = optim.Adam(model_deep_conv.parameters(), lr=0.001)
optimizer_deep_fc = optim.Adam(model_deep_fc.parameters(), lr=0.001)

train_accuracies_deep_conv, test_accuracy_deep_conv = train_and_evaluate(model_deep_conv, optimizer_deep_conv, train_loader_norm, test_loader_norm)

train_accuracies_deep_fc, test_accuracy_deep_fc = train_and_evaluate(model_deep_fc, optimizer_deep_fc, train_loader_norm, test_loader_norm)

params_deep_conv = sum(p.numel() for p in model_deep_conv.parameters() if p.requires_grad)
params_deep_fc = sum(p.numel() for p in model_deep_fc.parameters() if p.requires_grad)

print(f"CNN-Resnet with deeper convolutional layers: Accuracy = {test_accuracy_deep_conv}%, Parameters = {params_deep_conv}")
print(f"CNN-Resnet with more fully-connected layers: Accuracy = {test_accuracy_deep_fc}%, Parameters = {params_deep_fc}")

epochs = range(1, 51)

plt.figure(figsize=(10, 7))
plt.plot(epochs, train_accuracies_deep_conv, 'b-', label='CNN-Resnet Deeper Conv Layers')
plt.plot(epochs, train_accuracies_deep_fc, 'r-', label='CNN-Resnet More FCL')

plt.xlabel('Epoch')
plt.ylabel('Training Accuracy (%)')
plt.title('Training Accuracy vs. Epochs')
plt.legend()
plt.grid(True)
plt.show()

# Experiment 5
class CNNResnetDropout(nn.Module):
    def __init__(self, dropout_rate=0.5):
        super(CNNResnetDropout, self).__init__()
        self.layer1 = ResidualBlock(1, 32)
        self.layer2 = ResidualBlock(32, 64)
        self.dropout = nn.Dropout(dropout_rate)
        self.fc1 = nn.Linear(7*7*64, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x):
        x = self.layer1(x)
        x = torch.max_pool2d(x, 2)
        x = self.layer2(x)
        x = torch.max_pool2d(x, 2)
        x = x.view(-1, 7*7*64)
        x = self.dropout(x)
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x
    
model_dropout = CNNResnetDropout(dropout_rate=0.5).to(device)

optimizer = optim.Adam(model_dropout.parameters(), lr=0.001)

def train(model, train_loader, optimizer, device, epoch):
    model.train()
    correct = 0
    total = 0
    for batch_idx, (data, target) in enumerate(train_loader):
        data, target = data.to(device), target.to(device)
        optimizer.zero_grad()
        output = model(data)
        loss = F.cross_entropy(output, target)
        loss.backward()
        optimizer.step()
        
        pred = output.argmax(dim=1, keepdim=True)
        correct += pred.eq(target.view_as(pred)).sum().item()
        total += target.size(0)

        if batch_idx % 100 == 0:
            print(f"Train Epoch: {epoch} [{batch_idx * len(data)}/{len(train_loader.dataset)} ({100. * batch_idx / len(train_loader):.0f}%)]\tLoss: {loss.item():.6f}")
    
    train_accuracy = 100. * correct / total
    print(f'Training Accuracy: {train_accuracy:.2f}%')
    return train_accuracy

all_train_accuracies = []

def evaluate(model, test_loader):
    model.eval()
    test_loss = 0
    correct = 0
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            test_loss += F.cross_entropy(output, target, reduction='sum').item()
            pred = output.argmax(dim=1, keepdim=True)
            correct += pred.eq(target.view_as(pred)).sum().item()

    test_loss /= len(test_loader.dataset)
    print(f'\nTest set: Average loss: {test_loss:.4f}, Accuracy: {correct}/{len(test_loader.dataset)} ({100. * correct / len(test_loader.dataset):.0f}%)\n')

for epoch in range(1, 51):
    train_acc = train(model_dropout, train_loader_norm, optimizer, device, epoch)
    all_train_accuracies.append(train_acc)
    evaluate(model_dropout, test_loader_norm)

class ResidualBlockNoBN(nn.Module):
    def __init__(self, in_channels, out_channels, dropout_rate=0.5):
        super(ResidualBlockNoBN, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout_rate)
        if in_channels != out_channels:
            self.downsample = nn.Conv2d(in_channels, out_channels, kernel_size=1, padding=0)
        else:
            self.downsample = None

    def forward(self, x):
        identity = x
        out = self.conv1(x)
        out = self.relu(out)
        out = self.dropout(out)
        out = self.conv2(out)
        if self.downsample is not None:
            identity = self.downsample(x)
        out += identity
        out = self.relu(out)
        out = self.dropout(out)
        return out
class CNNResnetNoBN(nn.Module):
    def __init__(self, dropout_rate=0.5):
        super(CNNResnetNoBN, self).__init__()
        self.layer1 = ResidualBlockNoBN(1, 32, dropout_rate=dropout_rate)
        self.layer2 = ResidualBlockNoBN(32, 64, dropout_rate=dropout_rate)
        self.dropout = nn.Dropout(dropout_rate)
        self.fc1 = nn.Linear(7*7*64, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x):
        x = self.layer1(x)
        x = torch.max_pool2d(x, 2)
        x = self.layer2(x)
        x = torch.max_pool2d(x, 2)
        x = x.view(-1, 7*7*64)
        x = self.dropout(x)
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x
    
def train(model, train_loader, optimizer, device, epoch):
    model.train()
    correct = 0
    total = 0
    for batch_idx, (data, target) in enumerate(train_loader):
        data, target = data.to(device), target.to(device)
        optimizer.zero_grad()
        output = model(data)
        loss = F.cross_entropy(output, target)
        loss.backward()
        optimizer.step()
        
        pred = output.argmax(dim=1, keepdim=True)
        correct += pred.eq(target.view_as(pred)).sum().item()
        total += target.size(0)

    train_accuracy = 100. * correct / total
    return train_accuracy

def evaluate(model, test_loader, device):
    model.eval()
    test_loss = 0
    correct = 0
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            test_loss += F.cross_entropy(output, target, reduction='sum').item()
            pred = output.argmax(dim=1, keepdim=True)
            correct += pred.eq(target.view_as(pred)).sum().item()

    test_loss /= len(test_loader.dataset)
    test_accuracy = 100. * correct / len(test_loader.dataset)
    print(f'\nTest set: Average loss: {test_loss:.4f}, Accuracy: {correct}/{len(test_loader.dataset)} ({test_accuracy:.0f}%)\n')
    return test_accuracy

model = CNNResnetNoBN(dropout_rate=0.5).to(device)
optimizer = optim.Adam(model.parameters(), lr=0.001)

all_train_accuracies_dropout = []

for epoch in range(1, 51):
    train_acc = train(model, train_loader_norm, optimizer, device, epoch)
    all_train_accuracies_dropout.append(train_acc)
    print(f'Epoch {epoch}, Training Accuracy: {train_acc:.2f}%')
    test_acc = evaluate(model, test_loader_norm, device)

epochs = range(1, 51)

plt.figure(figsize=(10, 7))
plt.plot(epochs, all_train_accuracies, label='CNN-Resnet with Dropout and Batch Norm')
plt.plot(epochs, train_accuracies_resnet, label='CNN-Resnet with Batch Norm')
plt.plot(epochs, all_train_accuracies_dropout, label='CNN-Resnet with Dropout')

plt.xlabel('Epoch')
plt.ylabel('Training Accuracy (%)')
plt.title('Training Accuracy vs. Epochs')
plt.legend()
plt.grid(True)
plt.show()